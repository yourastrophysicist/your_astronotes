# Radio interferometer architecture

the typical signal chain of a radio interferometer, from sky to image. very different from optical: signals are voltages, can be heterodyne-mixed, recorded, and correlated electronically. this enables Earth-baseline arrays and post-correlation calibration.

## the chain

```
SOURCE →
  ANTENNA →
  RECEIVER (LNA, mixer, IF amplifier) →
  DIGITIZER (ADC) →
  CORRELATOR (multiply pairs of streams, integrate) →
  CALIBRATOR (apply gain/phase corrections) →
  IMAGER (CLEAN, deconvolve)
```

each stage is its own engineering art.

## antenna

a parabolic dish (mostly) that focuses the radio waves onto the feed horn at the focus. typical:

- **VLA**: 25 m diameter parabolic, alt-az mount
- **ALMA**: 12 m or 7 m diameter, on a transporter for reconfiguration
- **SKA**: 15 m (SKA-Mid) parabolic + 4 m square SKA-Low patch-antennas
- **EHT stations**: range from 10 m (SMT, Mt. Graham) to 30 m (IRAM 30m)

each dish has a primary beam (the antenna's diffraction pattern, $\sim \lambda/D$) which sets the field of view of the interferometer.

## receiver

a critical low-noise amplifier (LNA), often cooled to cryogenic temperatures. amplifies the weak radio signal by ~10$^7$ to ~10$^{10}$ before any further electronics. typical: HEMT amplifiers at cm wavelengths, SIS mixers at mm.

after LNA: a mixer converts the radio frequency (RF) to an intermediate frequency (IF) by mixing with a local oscillator (LO). e.g. RF = 230 GHz, LO = 230 GHz - 8 GHz = 222 GHz, IF = 8 GHz. the IF can be amplified and digitized with conventional electronics.

## digitizer

an ADC samples the IF signal at 2× the bandwidth (Nyquist). typical ALMA: 2 GHz bandwidth → 4 GS/s ADC. modern arrays (SKA-Low) digitize 100 MHz patches per ADC.

## correlator

multiplies signals from pairs of antennas and time-averages. this is where the interferometric information emerges. for $N$ antennas, $N(N-1)/2$ pair-multiplications per spectral channel.

modern correlators are FPGA- or GPU-based. ALMA's correlator handles 64 antennas × 8 GHz × 4 polarizations → ~5 PB/day raw data. data are reduced to ~100 GB/day visibility products.

## delay tracking

a critical correlator function. as the Earth rotates, the geometric delay between any two antennas changes. the correlator must subtract this expected delay before multiplication, otherwise the visibility decorrelates.

ALMA's correlator implements geometric delay tracking with picosecond precision.

## bandpass and gain calibration

after correlation, raw visibilities are calibrated:

- **bandpass calibrator**: a strong source whose flux is constant across the band, used to flatten the receiver's frequency response per antenna
- **flux calibrator**: a known absolute-flux source (typically Mars, an asteroid, or a quasar with measured spectrum), used to anchor the absolute scale
- **phase calibrator**: a nearby compact source whose true position is known, used to track atmospheric and instrumental phase shifts

these are observed periodically during a science observation (every few minutes).

## the signal chain advantage

key advantage over optical: **the signal is digital**. each antenna's data can be:
- recorded and transferred (VLBI: hard drives shipped between continents)
- played back through different correlators (offline reprocessing)
- correlated with simulated signals (model-based imaging)
- combined with optical-fiber-linked stations (e.g. the global VLBI Standard)

so radio interferometry has *flexibility* that optical does not. observations can be reanalyzed years later with new algorithms.

## the special architectures

### connected element interferometer

all antennas share a common LO (delivered via fiber or cabling). examples: VLA, ALMA, MeerKAT.

advantages:
- LO phase is automatically coherent across the array
- minimal post-correlation calibration
- real-time correlation possible

disadvantages:
- baseline limited by cabling/fiber length (typically <100 km)

### VLBI (very long baseline interferometry)

each station has its own LO (a hydrogen maser). signals are recorded with atomic-clock timing. correlation happens *post-hoc* at a central correlator.

advantages:
- baselines can be intercontinental
- arbitrarily long baselines from Earth-based stations

disadvantages:
- need atomic clocks at every station (expensive)
- post-correlation phase calibration (harder)
- data volumes are huge

## see also

- [[Radio astronomy basics]]
- [[Two-element correlator]]
- [[Connected element interferometer]]
- [[Very Long Baseline Interferometry VLBI]]
- [[Earth rotation synthesis in radio]]
- [[Astronomical_Interferometry_MOC]]
